# OmniReader — Universal Low-Latency Local Screen & Document Reader

A platform-agnostic, privacy-first local text-to-speech reader engineered to run entirely on your local machine's hardware processing power with near-zero latency (<250ms TTFA).

Triggerable from **any application across your OS** (Safari, Chrome, PDF viewers, Apple Books, Kindle, Notes, Slack, VS Code, Terminal) via macOS Quick Actions, global hotkeys, system tray menu, or CLI pipes.

---

## 1. Architecture

```text
[ Trigger: Global Hotkey / macOS Service / Tray / CLI ]
                           │
                           ▼
              [ Active Text Capture ]
       (Direct selection or clipboard buffer)
                           │
                           ▼
          [ Sentence & Markdown Splitter ]
   (Normalizes markdown, links, handles abbreviations)
                           │
       ┌───────────────────┴───────────────────┐
       │ Sentence 1          Sentence 2        │
       ▼                     ▼                 ▼
[ TTS Engine ]          [ TTS Engine ]    [ TTS Engine ]
(Kokoro ONNX int8 /     (Synthesizing     (Queued)
 System Native)          in background)
       │                     │
       ▼                     ▼
┌──────────────────────────────────────────────┐
│  Audio Queue & Stream (sounddevice / PCM)    │
│  Sentence 1 plays IMMEDIATELY                │
│  Sentence 2 ready before Sentence 1 ends     │
└──────────────────────────────────────────────┘
```

- **Pipelined Streaming**: Sentence $N$ is synthesized while Sentence $N-1$ is already playing. Latency to first audio is near-instant (<250ms) regardless of whether you are reading a 2-line tweet or a 600-page book.
- **Dual TTS Engine**:
  - **Kokoro Neural (ONNX int8)**: Studio-grade broadcast quality (82M params, 24kHz float32 audio, 54 voices).
  - **System Native**: Ultra-light instant fallback (macOS `say` / Linux `spd-say`/`espeak`).
- **Sample-Accurate Playback**: Non-blocking audio queue with instant pause, resume, skip, and stop controls.

---

## 2. OS-Wide Triggers

### Method A: macOS Native Quick Action (Recommended — Zero Permissions)
Highlight text in **any app** (Safari, Kindle, PDF, Notes, etc.) and trigger speech instantly:
1. Run `./scripts/install_macos_service.sh` (already installed).
2. Open macOS **System Settings** → **Keyboard** → **Keyboard Shortcuts...** → **Services** → **Text**.
3. Check **Read with OmniReader** and assign your preferred shortcut (e.g. `Cmd+Shift+S`).
4. Select text in any window and press `Cmd+Shift+S`.

### Method B: Native System Tray Menu
Run `omnisay --daemon` to start the macOS menu bar icon (or Linux tray):
- 🟢 **Idle**: Ready to read.
- 🔊 **Speaking**: Displays sentence progress (e.g. `Sentence 3/8`).
- ⏸️ **Paused**: Retains exact playback position.
- **Menu Controls**:
  - `Read Selection` / `Read Clipboard`
  - `Pause` / `Resume` / `Skip Sentence` / `Stop Speaking`
  - `Playback Speed` (1.0x, 1.2x, **1.4x default**, 1.6x, 1.8x, 2.0x)
  - `Voice` (Sky, Sarah, Bella, Nicole, Adam, Michael, Emma, Isabella, George, Lewis)
  - `Engine` (Kokoro Neural ONNX vs System Native)

### Method C: Global Hotkeys
When running with Accessibility permissions:
- **`Ctrl + Alt + R`**: Read highlighted selection (or clipboard).
- **`Ctrl + Alt + S`**: Halt speech immediately.

### Method D: Command Line & Pipes
The `omnisay` executable is linked to `~/.local/bin/omnisay`:
```bash
# Speak arbitrary text
omnisay "Local hardware execution ensures complete data privacy."

# Pipe an article or document
cat article.txt | omnisay
pbpaste | omnisay
curl -s "https://wttr.in/Berlin?format=3" | omnisay

# Read active selection or clipboard
omnisay --selection
omnisay --clipboard

# Control active playback
omnisay --pause
omnisay --resume
omnisay --toggle
omnisay --stop
omnisay --next

# Configure defaults on the fly
omnisay --speed 1.6
omnisay --voice af_sarah
omnisay --engine kokoro
omnisay --status
```

---

## 3. Linux Desktop Integration
On Linux (GNOME, KDE, i3, Sway, Hyprland), bind a shortcut to `omnisay`:
- **Wayland (Sway/GNOME)**: Bind `wl-paste -p | omnisay` to `Super+S` or `Ctrl+Alt+R`.
- **X11 (i3/KDE)**: Bind `xclip -o -selection primary | omnisay` to `$mod+s`.

---

## 4. Configuration
Persistent user configuration lives in `~/.config/omni_reader/config.json`:
```json
{
  "engine": "kokoro",
  "kokoro_voice": "af_sky",
  "system_voice": "default",
  "speed": 1.4,
  "sentence_pause": 0.20,
  "hotkey_read": "<ctrl>+<alt>+r",
  "hotkey_stop": "<ctrl>+<alt>+s",
  "models_dir": "/Users/j-aim1/.local/share/omni_reader/models",
  "socket_path": "/tmp/omni_reader.sock"
}
```

---

## 5. Model Weights
Model files reside in `~/.local/share/omni_reader/models/`:
- `kokoro-v1.0.int8.onnx` (88 MB quantized ONNX graph)
- `voices-v1.0.bin` (27 MB embeddings for 54 voices)
